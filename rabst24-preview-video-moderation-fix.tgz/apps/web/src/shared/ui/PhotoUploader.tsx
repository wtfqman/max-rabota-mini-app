import { useEffect, useMemo, useRef, useState } from 'react';
import { Camera, ImagePlus, X } from 'lucide-react';
import { MediaPreview, isVideoMedia } from './MediaPreview.js';

interface PhotoUploaderProps {
  files?: File[];
  maxFiles?: number;
  onFilesChange?: (files: File[]) => void;
}

export function PhotoUploader({ files, maxFiles = 8, onFilesChange }: PhotoUploaderProps) {
  const [internalFiles, setInternalFiles] = useState<File[]>([]);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const value = files ?? internalFiles;
  const previews = useObjectUrls(value);
  const availableSlots = Math.max(maxFiles - value.length, 0);
  const accept = 'image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime';

  const updateFiles = (nextFiles: File[]) => {
    if (onFilesChange) {
      onFilesChange(nextFiles.slice(0, maxFiles));
      return;
    }

    setInternalFiles(nextFiles.slice(0, maxFiles));
  };

  return (
    <div className="grid gap-3">
      <div className="flex items-center justify-between gap-3">
        <span className="text-xs font-extrabold uppercase tracking-[0.08em] text-text-secondary">Фото и видео</span>
        <span className="text-xs font-semibold text-text-muted">{value.length} из {maxFiles}</span>
      </div>

      {value.length === 0 ? (
        <label className="group flex min-h-[168px] cursor-pointer flex-col items-center justify-center gap-3 rounded-[24px] border border-dashed border-accent-green/45 bg-[radial-gradient(circle_at_top,rgba(52,211,153,0.14),transparent_44%),rgba(255,255,255,0.03)] px-4 text-center transition hover:border-accent-green hover:bg-accent-greenSoft/70 focus-within:outline focus-within:outline-2 focus-within:outline-offset-2 focus-within:outline-accent-green active:scale-[0.985]">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-accent-green/25 bg-accent-greenSoft text-accent-green transition group-hover:scale-105">
            <ImagePlus size={26} />
          </span>
          <span className="grid gap-1">
            <span className="text-base font-black text-text-primary">Добавить фото или видео</span>
            <span className="text-sm leading-5 text-text-secondary">Фото или короткое видео сделает объявление заметнее.</span>
          </span>
          <input
            ref={inputRef}
            className="sr-only"
            type="file"
            accept={accept}
            multiple
            onChange={(event) => {
              const selectedFiles = Array.from(event.target.files ?? []);
              updateFiles([...value, ...selectedFiles]);
              if (inputRef.current) {
                inputRef.current.value = '';
              }
            }}
          />
        </label>
      ) : (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {previews.map((preview, index) => (
            <div key={preview.url} className="group relative aspect-square overflow-hidden rounded-panel border border-white/8 bg-surface-900">
              <MediaPreview
                src={preview.url}
                mimeType={preview.file.type}
                className="h-full w-full object-cover transition duration-200 group-hover:scale-[1.02]"
                controls={false}
              />
              {index === 0 ? (
                <span className="absolute left-2 top-2 rounded-full bg-surface-950/80 px-2 py-1 text-[11px] font-semibold text-white">
                  Обложка
                </span>
              ) : null}
              {isVideoMedia(preview.url, preview.file.type) ? (
                <span className="absolute bottom-2 left-2 rounded-full bg-accent-greenSoft px-2 py-1 text-[11px] font-extrabold text-accent-green">
                  Видео
                </span>
              ) : null}
              <button
                type="button"
                className="absolute right-1.5 top-1.5 flex h-8 w-8 items-center justify-center rounded-full bg-surface-950/80 text-text-primary transition hover:bg-red-500/80 active:scale-95"
                aria-label="Удалить файл"
                onClick={() => updateFiles(value.filter((_, fileIndex) => fileIndex !== index))}
              >
                <X size={16} />
              </button>
            </div>
          ))}

          {availableSlots > 0 ? (
            <label className="flex aspect-square cursor-pointer flex-col items-center justify-center gap-2 rounded-panel border border-dashed border-accent-green/45 bg-accent-greenSoft/80 text-sm font-extrabold text-accent-green transition hover:border-accent-green hover:bg-accent-greenSoft focus-within:outline focus-within:outline-2 focus-within:outline-offset-2 focus-within:outline-accent-green active:scale-[0.985]">
              <ImagePlus size={22} />
              <span>Добавить</span>
              <input
                ref={inputRef}
                className="sr-only"
                type="file"
                accept={accept}
                multiple
                onChange={(event) => {
                  const selectedFiles = Array.from(event.target.files ?? []);
                  updateFiles([...value, ...selectedFiles]);
                  if (inputRef.current) {
                    inputRef.current.value = '';
                  }
                }}
              />
            </label>
          ) : null}

          {Array.from({ length: Math.min(2, availableSlots) }).map((_, index) => (
            <div
              key={`slot-${index}`}
              className="flex aspect-square items-center justify-center rounded-panel border border-white/8 bg-white/[0.02] text-text-muted"
            >
              <Camera size={22} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function useObjectUrls(files: File[]) {
  const previews = useMemo(
    () =>
      files.map((file) => ({
        file,
        url: URL.createObjectURL(file)
      })),
    [files]
  );

  useEffect(
    () => () => {
      previews.forEach((preview) => URL.revokeObjectURL(preview.url));
    },
    [previews]
  );

  return previews;
}
