interface MediaPreviewProps {
  src: string;
  mimeType?: string | null;
  alt?: string;
  className?: string;
  controls?: boolean;
  loading?: 'lazy' | 'eager';
}

export function MediaPreview({
  src,
  mimeType,
  alt = '',
  className,
  controls = true,
  loading = 'lazy'
}: MediaPreviewProps) {
  if (isVideoMedia(src, mimeType)) {
    return (
      <video
        src={src}
        className={className}
        controls={controls}
        muted={!controls}
        playsInline
        preload="metadata"
      />
    );
  }

  return <img src={src} alt={alt} className={className} loading={loading} />;
}

export function isVideoMedia(src?: string | null, mimeType?: string | null): boolean {
  if (mimeType?.startsWith('video/')) {
    return true;
  }

  return Boolean(src && /\.(mp4|webm|mov|m4v)(?:[?#].*)?$/i.test(src));
}
