import { randomUUID } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { AppError } from '@rabst24/shared';
import { FoundationService } from '../../shared/modules/module-status.js';
import type { UploadsRepository } from './uploads.repository.js';
import type { UploadPhotoDto } from './uploads.schemas.js';

export class UploadsService extends FoundationService {
  private static readonly imageMaxSizeBytes = 5 * 1024 * 1024;
  private static readonly videoMaxSizeBytes = 50 * 1024 * 1024;

  constructor(repository: UploadsRepository) {
    super(repository);
  }

  async uploadPhoto(dto: UploadPhotoDto) {
    const buffer = this.decodeDataUrl(dto.dataUrl, dto.mimeType);
    const maxSizeBytes = this.getMaxSizeBytes(dto.mimeType);

    if (buffer.byteLength > maxSizeBytes) {
      throw new AppError('File is too large', 400, {
        maxSizeBytes
      });
    }

    const extension = this.getExtension(dto.mimeType);
    const now = new Date();
    const directory = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}`;
    const fileName = `${randomUUID()}.${extension}`;
    const storageKey = `${directory}/${fileName}`;
    const uploadsRoot = path.resolve(process.cwd(), 'storage', 'uploads');
    const targetDirectory = path.join(uploadsRoot, directory);
    const targetPath = path.join(targetDirectory, fileName);

    await mkdir(targetDirectory, {
      recursive: true
    });
    await writeFile(targetPath, buffer);

    return {
      storageKey,
      url: `/uploads/${storageKey}`,
      previewUrl: `/uploads/${storageKey}`,
      mimeType: dto.mimeType,
      sizeBytes: buffer.byteLength,
      altText: dto.altText ?? null
    };
  }

  private decodeDataUrl(dataUrl: string, mimeType: string): Buffer {
    const prefix = `data:${mimeType};base64,`;

    if (!dataUrl.startsWith(prefix)) {
      throw new AppError('Invalid upload payload', 400);
    }

    return Buffer.from(dataUrl.slice(prefix.length), 'base64');
  }

  private getMaxSizeBytes(mimeType: string): number {
    return mimeType.startsWith('video/')
      ? UploadsService.videoMaxSizeBytes
      : UploadsService.imageMaxSizeBytes;
  }

  private getExtension(mimeType: string): string {
    if (mimeType === 'image/png') {
      return 'png';
    }

    if (mimeType === 'image/webp') {
      return 'webp';
    }

    if (mimeType === 'video/mp4') {
      return 'mp4';
    }

    if (mimeType === 'video/webm') {
      return 'webm';
    }

    if (mimeType === 'video/quicktime') {
      return 'mov';
    }

    return 'jpg';
  }
}
