import type { MaxButton, MaxInlineKeyboardAttachment } from '@rabst24/max-api';

export interface StartKeyboardOptions {
  miniAppUrl: string;
  miniAppWebApp?: string;
  channelUrl?: string;
}

export function createStartKeyboard(options: StartKeyboardOptions): MaxInlineKeyboardAttachment {
  const rows: MaxButton[][] = [];

  if (options.miniAppWebApp) {
    rows.push([
      {
        type: 'open_app',
        text: 'Открыть приложение',
        web_app: options.miniAppWebApp
      }
    ]);
  } else if (options.miniAppUrl) {
    rows.push([
      {
        type: 'link',
        text: 'Открыть приложение',
        url: options.miniAppUrl
      }
    ]);
  }

  if (options.channelUrl) {
    rows.push([
      {
        type: 'link',
        text: 'Открыть канал',
        url: options.channelUrl
      }
    ]);
  }

  return {
    type: 'inline_keyboard',
    payload: {
      buttons: rows
    }
  };
}
