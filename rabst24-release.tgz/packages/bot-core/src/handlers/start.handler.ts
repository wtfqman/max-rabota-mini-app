import { logger } from '@rabst24/config';
import type { UserService } from '@rabst24/core';
import type {
  MaxApiClient,
  MaxBotStartedUpdate,
  MaxMessageCreatedUpdate,
  MaxUser
} from '@rabst24/max-api';
import { createStartKeyboard } from '../keyboards/start.keyboard.js';

export interface StartHandlerOptions {
  miniAppUrl: string;
  miniAppWebApp?: string;
  channelUrl?: string;
}

export class StartHandler {
  constructor(
    private readonly userService: UserService,
    private readonly maxApiClient: MaxApiClient,
    private readonly options: StartHandlerOptions
  ) {}

  async handleBotStarted(update: MaxBotStartedUpdate): Promise<void> {
    await this.registerAndWelcome(update.user, update.user_locale);
  }

  async handleStartMessage(update: MaxMessageCreatedUpdate): Promise<void> {
    const sender = update.message.sender;

    if (!sender) {
      logger.warn({ update }, 'Cannot handle /start without sender');
      return;
    }

    if (sender.is_bot) {
      logger.debug({ sender }, 'Ignored /start from bot account');
      return;
    }

    await this.registerAndWelcome(sender, update.user_locale);
  }

  private async registerAndWelcome(maxUser: MaxUser, locale?: string | null): Promise<void> {
    const user = await this.userService.registerFromMaxUser(maxUser, locale);
    const welcomeText =
      'Привет! Это Rabst24.\n\n' +
      'Основной интерфейс находится в mini app. Здесь можно открыть приложение и канал.';

    try {
      await this.maxApiClient.sendMessage({
        userId: maxUser.user_id,
        body: {
          text: welcomeText,
          attachments: [
            createStartKeyboard({
              miniAppUrl: this.options.miniAppUrl,
              miniAppWebApp: this.options.miniAppWebApp,
              channelUrl: this.options.channelUrl
            })
          ]
        }
      });
    } catch (error) {
      logger.warn({ err: error, maxUserId: maxUser.user_id.toString() }, 'Failed to send start keyboard, retrying with plain text');

      await this.maxApiClient.sendMessage({
        userId: maxUser.user_id,
        body: {
          text: `${welcomeText}\n\nЕсли кнопка приложения не открывается, мини-приложение нужно подключить в MAX Partner.`
        }
      });
    }

    logger.info({ userId: user.id, maxUserId: user.maxUserId.toString() }, 'User started bot');
  }
}
