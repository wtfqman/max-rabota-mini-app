import { Outlet } from 'react-router-dom';
import { BottomTabBar } from '../../shared/ui/BottomTabBar.js';
import { ScrollToTop } from './ScrollToTop.js';

export function AppShell() {
  return (
    <div className="app-shell min-h-screen text-text-primary">
      <ScrollToTop />
      <main className="mx-auto min-h-screen w-full max-w-xl px-4 pb-40 pt-4 app-fade-in">
        <Outlet />
      </main>
      <BottomTabBar />
    </div>
  );
}
