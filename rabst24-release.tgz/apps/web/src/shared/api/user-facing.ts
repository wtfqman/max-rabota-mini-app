﻿import { ApiError } from './http.js';

type ErrorContext =
  | 'app_init'
  | 'profile_load'
  | 'favorites_load'
  | 'vacancies_load'
  | 'vacancy_load'
  | 'ad_load'
  | 'moderation_load'
  | 'moderation_action'
  | 'reviews_load'
  | 'review_submit'
  | 'my_ads_load'
  | 'vacancy_submit'
  | 'resume_submit'
  | 'equipment_submit'
  | 'product_submit'
  | 'photo_upload';

const authMessage = 'РќСѓР¶РЅРѕ Р·Р°РЅРѕРІРѕ РѕС‚РєСЂС‹С‚СЊ mini app С‡РµСЂРµР· MAX.';
const genericDataMessage = 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РґР°РЅРЅС‹Рµ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.';
const genericSubmitMessage = 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ РѕР±СЉСЏРІР»РµРЅРёРµ. РџСЂРѕРІРµСЂСЊС‚Рµ РґР°РЅРЅС‹Рµ Рё РїРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.';

const messages: Record<ErrorContext, { default: string; auth: string }> = {
  app_init: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РєСЂС‹С‚СЊ РїСЂРёР»РѕР¶РµРЅРёРµ. РџРѕРїСЂРѕР±СѓР№С‚Рµ Р·Р°Р№С‚Рё РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  profile_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РїСЂРѕС„РёР»СЊ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  favorites_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РёР·Р±СЂР°РЅРЅРѕРµ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  vacancies_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РѕР±СЉСЏРІР»РµРЅРёСЏ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  vacancy_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РєСЂС‹С‚СЊ РІР°РєР°РЅСЃРёСЋ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  ad_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РєСЂС‹С‚СЊ РѕР±СЉСЏРІР»РµРЅРёРµ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  moderation_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РјРѕРґРµСЂР°С†РёСЋ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  moderation_action: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ РІС‹РїРѕР»РЅРёС‚СЊ РґРµР№СЃС‚РІРёРµ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  reviews_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РѕС‚Р·С‹РІС‹. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  review_submit: {
    default: 'Не удалось отправить отзыв. Проверьте текст и попробуйте ещё раз.',
    auth: authMessage
  },
  my_ads_load: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ РІР°С€Рё РѕР±СЉСЏРІР»РµРЅРёСЏ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  vacancy_submit: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ РІР°РєР°РЅСЃРёСЋ. РџСЂРѕРІРµСЂСЊС‚Рµ РґР°РЅРЅС‹Рµ Рё РїРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  resume_submit: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ СЂРµР·СЋРјРµ. РџСЂРѕРІРµСЂСЊС‚Рµ РґР°РЅРЅС‹Рµ Рё РїРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  },
  equipment_submit: {
    default: genericSubmitMessage,
    auth: authMessage
  },
  product_submit: {
    default: genericSubmitMessage,
    auth: authMessage
  },
  photo_upload: {
    default: 'РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РіСЂСѓР·РёС‚СЊ С„РѕС‚Рѕ. РџРѕРїСЂРѕР±СѓР№С‚Рµ РІС‹Р±СЂР°С‚СЊ РёР·РѕР±СЂР°Р¶РµРЅРёРµ РµС‰С‘ СЂР°Р·.',
    auth: authMessage
  }
};

export function getUserFacingError(error: unknown, context: ErrorContext): string {
  const messageSet = messages[context];

  if (error instanceof ApiError) {
    if (error.status === 401 || error.status === 403) {
      return messageSet.auth;
    }

    if (error.status === 404) {
      return getNotFoundMessage(context) ?? messageSet.default;
    }

    const normalized = normalizeKnownTechnicalMessage(error.message);
    if (normalized) {
      return normalized;
    }

    if (isSafeHumanMessage(error.message)) {
      return error.message.trim();
    }
  }

  if (error instanceof Error) {
    const normalized = normalizeKnownTechnicalMessage(error.message);
    if (normalized) {
      return normalized;
    }

    if (isSafeHumanMessage(error.message)) {
      return error.message.trim();
    }
  }

  return messageSet.default;
}

function getNotFoundMessage(context: ErrorContext): string | null {
  if (context === 'ad_load' || context === 'vacancy_load') {
    return 'РќРµ РЅР°С€Р»Рё СЌС‚Рѕ РѕР±СЉСЏРІР»РµРЅРёРµ. Р’РѕР·РјРѕР¶РЅРѕ, РµРіРѕ СЃРЅСЏР»Рё СЃ РїСѓР±Р»РёРєР°С†РёРё.';
  }

  if (context === 'profile_load') {
    return 'РџСЂРѕС„РёР»СЊ РїРѕРєР° РЅРµ РЅР°Р№РґРµРЅ. РћС‚РєСЂРѕР№С‚Рµ mini app Р·Р°РЅРѕРІРѕ С‡РµСЂРµР· MAX.';
  }

  return null;
}

function normalizeKnownTechnicalMessage(message: string): string | null {
  const lower = message.trim().toLowerCase();

  if (!lower) {
    return null;
  }

  if (lower.includes('video is not supported')) {
    return 'Видео уже поддерживается. Обновите приложение и попробуйте выбрать MP4, MOV или WebM ещё раз.';
  }

  if (lower.includes('file is too large')) {
    return 'Файл слишком большой. Фото можно до 5 МБ, видео до 60 МБ.';
  }

  if (lower.includes('invalid upload payload')) {
    return 'Не удалось загрузить файл. Поддерживаются фото JPEG/PNG/WebP и видео MP4/MOV/WebM.';
  }

  if (
    lower.includes('authentication required') ||
    lower.includes('auth required') ||
    lower.includes('invalid access_token') ||
    lower.includes('verify.token') ||
    lower.includes('unauthorized')
  ) {
    return authMessage;
  }

  if (lower.includes('pending moderation')) {
    return 'РћР±СЉСЏРІР»РµРЅРёРµ РЅР° РјРѕРґРµСЂР°С†РёРё.';
  }

  if (lower === 'pending' || lower.includes('pending state')) {
    return 'РќР° РјРѕРґРµСЂР°С†РёРё.';
  }

  if (lower.includes('rejected')) {
    return 'РћС‚РєР»РѕРЅРµРЅРѕ.';
  }

  if (lower.includes('draft')) {
    return 'Р§РµСЂРЅРѕРІРёРє.';
  }

  if (
    lower.includes('failed to load') ||
    lower.includes('api request failed') ||
    lower.includes('failed to fetch') ||
    lower.includes('networkerror')
  ) {
    return genericDataMessage;
  }

  return null;
}

function isSafeHumanMessage(message: string): boolean {
  const raw = message.trim();
  const lower = raw.toLowerCase();

  if (!raw || raw.length > 180 || !/[а-яё]/i.test(raw)) {
    return false;
  }

  return ![
    'authentication required',
    'auth required',
    'pending',
    'rejected',
    'draft',
    'raw',
    'api request failed',
    'failed to fetch',
    'prisma',
    'stack',
    'validation',
    'internal',
    'debug',
    'schema',
    'database',
    'access_token',
    'token',
    'undefined',
    'null',
    'json',
    'route',
    'exception',
    '/api',
    'server returned',
    'СЃРµСЂРІРµСЂ РІРµСЂРЅСѓР»',
    'РІРЅСѓС‚СЂРµРЅ',
    'С‚РµС…РЅРёС‡РµСЃ'
  ].some((token) => lower.includes(token));
}

export function getRoleLabel(role: 'user' | 'moderator' | 'admin'): string {
  if (role === 'admin') {
    return 'РђРґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂ';
  }

  if (role === 'moderator') {
    return 'РљРѕРјР°РЅРґР° Rabst24';
  }

  return 'РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ';
}

export function getStatusLabel(status: 'active' | 'blocked' | 'deleted'): string {
  if (status === 'blocked') {
    return 'РќР° РїР°СѓР·Рµ';
  }

  if (status === 'deleted') {
    return 'РЎРєСЂС‹С‚';
  }

  return 'РђРєС‚РёРІРµРЅ';
}
