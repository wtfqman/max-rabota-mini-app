﻿import type { ReactNode } from 'react';
import clsx from 'clsx';

interface StatChipProps {
  label: string;
  value?: string;
  tone?: 'green' | 'neutral';
  icon?: ReactNode;
}

export function StatChip({ label, value, tone = 'neutral', icon }: StatChipProps) {
  return (
    <span
      className={clsx(
        'inline-flex min-h-9 items-center gap-2 rounded-full border px-3 text-sm font-bold backdrop-blur-sm',
        tone === 'green' && 'border-accent-green/25 bg-accent-greenSoft text-accent-green',
        tone === 'neutral' && 'border-white/10 bg-white/[0.04] text-text-secondary'
      )}
    >
      {icon}
      <span>
        {value ? `${value} ` : null}
        {label}
      </span>
    </span>
  );
}
