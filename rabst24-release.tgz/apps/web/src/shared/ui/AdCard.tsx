import { BriefcaseBusiness, FileUser, Heart, MapPin, Package, Tag, Truck, Wrench } from 'lucide-react';
import { Link } from 'react-router-dom';
import { MediaPreview } from './MediaPreview.js';
import { StatChip } from './StatChip.js';

export interface AdCardProps {
  to: string;
  title: string;
  typeLabel: string;
  variant?: 'default' | 'compact';
  location?: string | null;
  price?: string;
  description?: string | null;
  subtitle?: string | null;
  coverImageUrl?: string | null;
  coverMimeType?: string | null;
  category?: string | null;
  chips?: Array<{ key: string; value: string }>;
  isFavorite?: boolean;
  onFavoriteClick?: () => void;
}

export function AdCard({
  to,
  title,
  typeLabel,
  variant = 'default',
  location,
  price,
  description,
  subtitle,
  coverImageUrl,
  coverMimeType,
  category,
  chips = [],
  isFavorite,
  onFavoriteClick
}: AdCardProps) {
  const Icon = getTypeIcon(typeLabel);

  if (variant === 'compact') {
    return (
      <Link
        to={to}
        className="app-surface app-topline block overflow-hidden rounded-panel p-4 transition duration-200 hover:translate-y-[-1px] hover:border-accent-green/35 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent-green active:scale-[0.985]"
      >
        <article className="space-y-4">
          <div className="flex items-start gap-3">
            {coverImageUrl ? (
              <div className="h-20 w-20 shrink-0 overflow-hidden rounded-panel border border-white/10 bg-surface-800">
                <MediaPreview src={coverImageUrl} mimeType={coverMimeType} className="h-full w-full object-cover" controls={false} />
              </div>
            ) : (
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-panel border border-accent-green/20 bg-accent-greenSoft text-accent-green">
                <Icon size={24} />
              </div>
            )}

            <div className="min-w-0 flex-1 pt-1">
              <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-accent-green">{typeLabel}</p>
              <h2 className="mt-1 line-clamp-2 text-2xl font-black leading-tight text-text-primary">{title}</h2>
              {subtitle ? <p className="mt-1 line-clamp-1 text-sm font-semibold text-text-secondary">{subtitle}</p> : null}
            </div>

            {onFavoriteClick ? (
              <button
                type="button"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/10 bg-surface-900/92 text-white transition hover:border-accent-green/40 active:scale-95"
                aria-label={isFavorite ? 'Убрать из избранного' : 'Добавить в избранное'}
                onClick={(event) => {
                  event.preventDefault();
                  onFavoriteClick();
                }}
              >
                <Heart className={isFavorite ? 'fill-accent-green text-accent-green' : ''} size={20} />
              </button>
            ) : null}
          </div>

          {description ? <p className="line-clamp-2 text-sm leading-5 text-text-secondary">{description}</p> : null}

          <div className="flex flex-wrap gap-2">
            {location ? <StatChip label={location} icon={<MapPin size={15} />} /> : null}
            {price ? <StatChip label={price} tone="green" /> : null}
            {category ? <StatChip label={category} tone="green" icon={<Tag size={15} />} /> : null}
            {chips.map((chip) => (
              <StatChip key={chip.key} label={chip.value} />
            ))}
          </div>
        </article>
      </Link>
    );
  }

  return (
    <Link
      to={to}
      className="app-surface block overflow-hidden rounded-panel transition duration-200 hover:translate-y-[-1px] hover:border-accent-green/35 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent-green active:scale-[0.985]"
    >
      <article className="space-y-4">
        {coverImageUrl ? (
          <div className="relative aspect-[16/9] overflow-hidden bg-surface-800">
            <MediaPreview src={coverImageUrl} mimeType={coverMimeType} className="h-full w-full object-cover" controls={false} />
            <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-surface-950/90 to-transparent" />
            <span className="absolute left-4 top-4 rounded-full border border-black/20 bg-surface-950/78 px-3 py-1 text-xs font-extrabold text-accent-green backdrop-blur">
              {typeLabel}
            </span>
          </div>
        ) : (
          <div className="relative flex aspect-[16/9] items-end overflow-hidden bg-[linear-gradient(135deg,rgba(52,211,153,0.18),transparent_42%),linear-gradient(180deg,#101815,#050807)] px-4 py-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-panel border border-accent-green/20 bg-accent-greenSoft text-accent-green">
              <Icon size={22} />
            </div>
          </div>
        )}

        <div className="flex items-start justify-between gap-3 px-4 pt-4">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-panel border border-accent-green/20 bg-accent-greenSoft text-accent-green">
              <Icon size={22} />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-extrabold uppercase tracking-[0.08em] text-accent-green">{typeLabel}</p>
              <h2 className="truncate text-xl font-black text-text-primary">{title}</h2>
              {subtitle ? <p className="truncate text-sm text-text-secondary">{subtitle}</p> : null}
            </div>
          </div>
          {onFavoriteClick ? (
            <button
              type="button"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/10 bg-surface-900/92 text-white transition hover:border-accent-green/40 hover:text-accent-green active:scale-95"
              aria-label={isFavorite ? 'Убрать из избранного' : 'Добавить в избранное'}
              onClick={(event) => {
                event.preventDefault();
                onFavoriteClick();
              }}
            >
              <Heart className={isFavorite ? 'fill-accent-green text-accent-green' : ''} size={21} />
            </button>
          ) : null}
        </div>

        <div className="space-y-3 px-4 pb-4">
          {description ? <p className="line-clamp-2 text-sm leading-5 text-text-secondary">{description}</p> : null}
          <div className="flex flex-wrap gap-2">
            {location ? <StatChip label={location} icon={<MapPin size={15} />} /> : null}
            {price ? <StatChip label={price} tone="green" /> : null}
            {category ? <StatChip label={category} tone="green" icon={<Tag size={15} />} /> : null}
            {chips.map((chip) => (
              <StatChip key={chip.key} label={chip.value} />
            ))}
          </div>
        </div>
      </article>
    </Link>
  );
}

function getTypeIcon(typeLabel: string) {
  const normalized = typeLabel.toLowerCase();

  if (normalized.includes('резюме')) {
    return FileUser;
  }

  if (normalized.includes('материал')) {
    return Package;
  }

  if (normalized.includes('инструмент')) {
    return Wrench;
  }

  if (
    normalized.includes('техник') ||
    normalized.includes('экскаватор') ||
    normalized.includes('кран') ||
    normalized.includes('груз')
  ) {
    return Truck;
  }

  return BriefcaseBusiness;
}

export function AdCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-panel border border-white/8 bg-surface-850 shadow-panel">
      <div className="soft-shimmer aspect-[16/9] bg-surface-800" />
      <div className="space-y-4">
        <div className="flex gap-3 p-4">
          <div className="soft-shimmer h-11 w-11 rounded-panel bg-surface-700" />
          <div className="flex-1 space-y-2">
            <div className="soft-shimmer h-4 w-24 rounded bg-surface-700" />
            <div className="soft-shimmer h-5 w-3/4 rounded bg-surface-700" />
          </div>
        </div>
        <div className="space-y-2 px-4 pb-4">
          <div className="soft-shimmer h-4 rounded bg-surface-700" />
          <div className="soft-shimmer h-4 w-2/3 rounded bg-surface-700" />
        </div>
      </div>
    </div>
  );
}
