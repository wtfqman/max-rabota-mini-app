﻿import type { ReactNode } from 'react';

interface FormSectionProps {
  title: string;
  description?: string;
  children: ReactNode;
}

export function FormSection({ title, description, children }: FormSectionProps) {
  return (
    <fieldset className="app-surface app-topline space-y-4 rounded-panel p-4 app-fade-up">
      <legend className="px-1 text-lg font-extrabold text-text-primary">{title}</legend>
      {description ? <p className="text-sm leading-5 text-text-secondary">{description}</p> : null}
      <div className="grid gap-4">{children}</div>
    </fieldset>
  );
}
