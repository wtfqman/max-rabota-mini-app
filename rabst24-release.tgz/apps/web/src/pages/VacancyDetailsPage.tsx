﻿import { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  BriefcaseBusiness,
  Building2,
  CheckCircle2,
  Heart,
  Phone,
  RefreshCw,
  Send,
  Share2,
  ShieldCheck
} from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import type { PublicAdContact, PublicVacancyDetail } from '../features/vacancies/vacancy.types.js';
import { apiClient } from '../shared/api/client.js';
import { getUserFacingError } from '../shared/api/user-facing.js';
import { ActionButton } from '../shared/ui/ActionButton.js';
import { AdCardSkeleton } from '../shared/ui/AdCard.js';
import { AppPage } from '../shared/ui/AppPage.js';
import { EmptyState } from '../shared/ui/EmptyState.js';
import { MediaPreview } from '../shared/ui/MediaPreview.js';
import { SectionCard } from '../shared/ui/SectionCard.js';
import { StatChip } from '../shared/ui/StatChip.js';
import { ReviewsBlock } from '../features/reviews/ReviewsBlock.js';

export function VacancyDetailsPage() {
  const { adId } = useParams();
  const [vacancy, setVacancy] = useState<PublicVacancyDetail | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);
  const [shareLabel, setShareLabel] = useState('РџРѕРґРµР»РёС‚СЊСЃСЏ');

  useEffect(() => {
    apiClient
      .listFavorites()
      .then((response) => {
        setIsFavorite(Boolean(adId && response.data.some((item) => item.ad.id === adId)));
      })
      .catch(() => {
        setIsFavorite(false);
      });
  }, [adId]);

  useEffect(() => {
    if (!adId) {
      setStatus('error');
      setError('Р’Р°РєР°РЅСЃРёСЏ РЅРµ РЅР°Р№РґРµРЅР°.');
      return;
    }

    let isActive = true;
    setStatus('loading');
    setError(null);

    apiClient
      .getVacancyDetails(adId)
      .then((response) => {
        if (!isActive) {
          return;
        }

        setVacancy(response.data);
        setStatus('ready');
      })
      .catch((requestError: unknown) => {
        if (!isActive) {
          return;
        }

        setError(getUserFacingError(requestError, 'vacancy_load'));
        setStatus('error');
      });

    return () => {
      isActive = false;
    };
  }, [adId, reloadKey]);

  const heroPhoto = vacancy?.coverPhoto ?? vacancy?.photos[0] ?? null;
  const facts = useMemo(() => (vacancy ? buildFacts(vacancy) : []), [vacancy]);

  const handleShare = async () => {
    if (!vacancy) {
      return;
    }

    const url = window.location.href;
    const shareData = {
      title: vacancy.title,
      text: vacancy.subtitle ?? 'Р’Р°РєР°РЅСЃРёСЏ РІ Rabst24',
      url
    };
    const maybeNavigator = navigator as Navigator & {
      share?: (data: typeof shareData) => Promise<void>;
    };

    try {
      if (maybeNavigator.share) {
        await maybeNavigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(url);
        setShareLabel('РЎСЃС‹Р»РєР° СЃРєРѕРїРёСЂРѕРІР°РЅР°');
        window.setTimeout(() => setShareLabel('РџРѕРґРµР»РёС‚СЊСЃСЏ'), 1800);
      }
    } catch {
      setShareLabel('РќРµ РїРѕР»СѓС‡РёР»РѕСЃСЊ');
      window.setTimeout(() => setShareLabel('РџРѕРґРµР»РёС‚СЊСЃСЏ'), 1800);
    }
  };

  const toggleFavorite = async () => {
    if (!vacancy) {
      return;
    }

    const previous = isFavorite;
    setIsFavorite(!previous);

    try {
      if (previous) {
        await apiClient.removeFavorite(vacancy.id);
      } else {
        await apiClient.addFavorite(vacancy.id);
      }
    } catch {
      setIsFavorite(previous);
    }
  };

  if (status === 'loading') {
    return (
      <AppPage>
        <Link to="/vacancies" className="inline-flex items-center gap-2 text-sm font-semibold text-text-secondary">
          <ArrowLeft size={17} />
          Рљ РІР°РєР°РЅСЃРёСЏРј
        </Link>
        <AdCardSkeleton />
        <AdCardSkeleton />
      </AppPage>
    );
  }

  if (status === 'error' || !vacancy) {
    return (
      <AppPage>
        <Link to="/vacancies" className="inline-flex items-center gap-2 text-sm font-semibold text-text-secondary">
          <ArrowLeft size={17} />
          Рљ РІР°РєР°РЅСЃРёСЏРј
        </Link>
        <EmptyState
          title="РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РєСЂС‹С‚СЊ РІР°РєР°РЅСЃРёСЋ"
          description={error ?? 'Р’РµСЂРЅРёС‚РµСЃСЊ РІ СЃРїРёСЃРѕРє Рё РїРѕРїСЂРѕР±СѓР№С‚Рµ СЃРЅРѕРІР°.'}
          action={
            <ActionButton icon={<RefreshCw size={18} />} onClick={() => setReloadKey((value) => value + 1)}>
              РћР±РЅРѕРІРёС‚СЊ
            </ActionButton>
          }
        />
      </AppPage>
    );
  }

  return (
    <AppPage>
      <Link to="/vacancies" className="inline-flex items-center gap-2 text-sm font-semibold text-text-secondary">
        <ArrowLeft size={17} />
        Рљ РІР°РєР°РЅСЃРёСЏРј
      </Link>

      <section className="app-surface app-topline relative overflow-hidden rounded-panel p-5 shadow-glow app-fade-up">
        <div className="pointer-events-none absolute -right-20 -top-20 h-52 w-52 rounded-full bg-accent-green/12 blur-3xl" />
        <div className="relative space-y-5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-accent-green/25 bg-accent-greenSoft text-accent-green">
              <BriefcaseBusiness size={26} />
            </div>
            <div className="flex flex-wrap justify-end gap-2">
              <StatChip label="Р’Р°РєР°РЅСЃРёСЏ" tone="green" />
              <StatChip label="РџСЂРѕРІРµСЂРµРЅРѕ" tone="green" icon={<ShieldCheck size={15} />} />
            </div>
          </div>

          <div className="space-y-3">
            <h1 className="text-4xl font-black leading-none tracking-[-0.04em] text-text-primary">{vacancy.title}</h1>
            {vacancy.subtitle ? (
              <p className="flex items-center gap-2 text-base font-semibold text-text-secondary">
                <Building2 size={18} className="shrink-0 text-accent-green" />
                {vacancy.subtitle}
              </p>
            ) : null}
            {vacancy.shortSalary ? <p className="text-3xl font-black text-accent-green">{vacancy.shortSalary}</p> : null}
          </div>

          <div className="grid grid-cols-2 gap-2">
            {facts.map((fact) => (
              <div key={fact.label} className="rounded-panel border border-white/10 bg-black/[0.18] p-3">
                <p className="text-[11px] font-extrabold uppercase tracking-[0.08em] text-text-muted">{fact.label}</p>
                <p className="mt-1 text-base font-extrabold leading-tight text-text-primary">{fact.value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {vacancy.photos.length > 0 || heroPhoto ? (
        <SectionCard title="Медиа" description="Все фото и видео из объявления. Первое фото используется как обложка.">
          <VacancyMediaGallery media={vacancy.photos.length > 0 ? vacancy.photos : heroPhoto ? [heroPhoto] : []} title={vacancy.title} />
        </SectionCard>
      ) : null}

      {vacancy.vacancy.metroStations.length > 0 ? (
        <SectionCard title="РњРµС‚СЂРѕ">
          <div className="grid gap-2">
            {vacancy.vacancy.metroStations.map((metro) => (
              <div key={metro.id} className="flex items-center justify-between gap-3 rounded-panel bg-surface-900/92 p-3">
                <div className="flex min-w-0 items-center gap-3">
                  <span
                    className="h-3 w-3 shrink-0 rounded-full"
                    style={{ backgroundColor: metro.lineColor ?? '#3ddbd9' }}
                  />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-text-primary">{metro.name}</p>
                    {metro.lineName ? <p className="truncate text-xs text-text-muted">{metro.lineName}</p> : null}
                  </div>
                </div>
                {metro.walkingMinutes ? (
                  <span className="text-sm font-semibold text-text-secondary">{metro.walkingMinutes} РјРёРЅ</span>
                ) : null}
              </div>
            ))}
          </div>
        </SectionCard>
      ) : null}

      {vacancy.description ? (
        <SectionCard title="РћРїРёСЃР°РЅРёРµ">
          <p className="whitespace-pre-line text-base leading-7 text-text-secondary">{vacancy.description}</p>
        </SectionCard>
      ) : null}

      <TextListSection title="Р§С‚Рѕ РІР°Р¶РЅРѕ РѕС‚ РєР°РЅРґРёРґР°С‚Р°" items={vacancy.requirements} />
      <TextListSection title="Р§С‚Рѕ РЅСѓР¶РЅРѕ РґРµР»Р°С‚СЊ" items={vacancy.responsibilities} />
      <TextListSection title="Р§С‚Рѕ РїСЂРµРґР»Р°РіР°РµС‚ СЂР°Р±РѕС‚РѕРґР°С‚РµР»СЊ" items={vacancy.benefits} />

      <SectionCard title="РљРѕРЅС‚Р°РєС‚С‹" description="РЎРІСЏР·Р°С‚СЊСЃСЏ РјРѕР¶РЅРѕ РЅР°РїСЂСЏРјСѓСЋ РїРѕ РґР°РЅРЅС‹Рј РёР· РѕР±СЉСЏРІР»РµРЅРёСЏ.">
        {vacancy.contacts.length > 0 ? (
          <div className="grid gap-2">
            {vacancy.contacts.map((contact) => (
              <a
                key={contact.id}
                href={getContactHref(contact)}
                className="flex items-center justify-between gap-3 rounded-panel border border-white/8 bg-surface-900/92 p-3 transition hover:border-accent-green/35"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <Phone size={18} className="shrink-0 text-accent-green" />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-text-primary">{contact.label ?? contact.type.toUpperCase()}</p>
                    <p className="truncate text-sm text-text-secondary">{contact.value}</p>
                  </div>
                </div>
                {contact.isPreferred ? <StatChip label="РћСЃРЅРѕРІРЅРѕР№" tone="green" /> : null}
              </a>
            ))}
          </div>
        ) : (
          <p className="text-sm text-text-secondary">РљРѕРЅС‚Р°РєС‚С‹ РїРѕСЏРІСЏС‚СЃСЏ Р·РґРµСЃСЊ, РєРѕРіРґР° СЂР°Р±РѕС‚РѕРґР°С‚РµР»СЊ РёС… РґРѕР±Р°РІРёС‚.</p>
        )}
      </SectionCard>

      <ReviewsBlock subjectUserId={vacancy.owner.id} adId={vacancy.id} adTitle={vacancy.title} />

      <div className="text-center text-sm text-text-muted">
        РћРїСѓР±Р»РёРєРѕРІР°РЅРѕ {formatDate(vacancy.publishedAt ?? vacancy.createdAt)}
      </div>

      <div className="sticky bottom-[108px] z-10 grid grid-cols-[1fr_auto_auto] gap-2 rounded-[22px] border border-white/10 bg-surface-950/88 p-2 shadow-[0_-16px_46px_rgba(0,0,0,0.42)] backdrop-blur-xl">
        <ActionButton icon={<Send size={18} />}>РЎРІСЏР·Р°С‚СЊСЃСЏ</ActionButton>
        <ActionButton
          variant="secondary"
          aria-label={isFavorite ? 'РЈР±СЂР°С‚СЊ РёР· РёР·Р±СЂР°РЅРЅРѕРіРѕ' : 'Р”РѕР±Р°РІРёС‚СЊ РІ РёР·Р±СЂР°РЅРЅРѕРµ'}
          icon={<Heart className={isFavorite ? 'fill-accent-green text-accent-green' : ''} size={19} />}
          onClick={() => void toggleFavorite()}
        />
        <ActionButton variant="secondary" aria-label={shareLabel} icon={<Share2 size={19} />} onClick={handleShare} />
      </div>
    </AppPage>
  );
}

function VacancyMediaGallery({ media, title }: { media: PublicVacancyDetail['photos']; title: string }) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {media.map((item) => (
        <div key={item.id} className="h-40 overflow-hidden rounded-[18px] border border-white/10 bg-surface-900">
          <MediaPreview
            src={item.previewUrl ?? item.url}
            mimeType={item.mimeType}
            alt={item.altText ?? title}
            className="h-full w-full object-cover"
          />
        </div>
      ))}
    </div>
  );
}

function TextListSection({ title, items }: { title: string; items: string[] }) {
  if (items.length === 0) {
    return null;
  }

  return (
    <SectionCard title={title}>
      <ul className="grid gap-3">
        {items.map((item) => (
          <li key={item} className="flex gap-3 text-base leading-6 text-text-secondary">
            <CheckCircle2 size={18} className="mt-1 shrink-0 text-accent-green" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </SectionCard>
  );
}

function buildFacts(vacancy: PublicVacancyDetail) {
  return [
    { label: 'Р›РѕРєР°С†РёСЏ', value: vacancy.locationShort },
    { label: 'РљР°С‚РµРіРѕСЂРёСЏ', value: vacancy.category },
    { label: 'Р“СЂР°С„РёРє', value: vacancy.vacancy.schedule },
    { label: 'РћРїС‹С‚', value: vacancy.vacancy.experience }
  ].filter((fact): fact is { label: string; value: string } => Boolean(fact.value));
}

function getContactHref(contact: PublicAdContact): string {
  if (contact.type === 'phone') {
    return `tel:${contact.value.replace(/[^\d+]/g, '')}`;
  }

  if (contact.type === 'email') {
    return `mailto:${contact.value}`;
  }

  if (contact.type === 'website') {
    return contact.value.startsWith('http') ? contact.value : `https://${contact.value}`;
  }

  return '#';
}

function formatDate(value: string): string {
  return new Intl.DateTimeFormat('ru-RU', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(new Date(value));
}

