﻿import {
  ArrowRight,
  ClipboardList,
  FileUser,
  HardHat,
  Megaphone,
  Package,
  PlusCircle,
  Search,
  ShieldCheck,
  Truck,
  Wrench
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppPage } from '../shared/ui/AppPage.js';
import { TileCard } from '../shared/ui/TileCard.js';

const sections = [
  {
    to: '/vacancies',
    title: 'Вакансии',
    description: 'Работа, подработки и заказы на строительных объектах.',
    icon: <HardHat size={24} />,
    tone: 'green' as const
  },
  {
    to: '/resumes',
    title: 'Резюме',
    description: 'Анкеты специалистов, бригадиров и рабочих.',
    icon: <FileUser size={24} />,
    tone: 'green' as const
  },
  {
    to: '/equipment',
    title: 'Строительная техника',
    description: 'Аренда и продажа техники для стройки и ремонта.',
    icon: <Truck size={24} />,
    tone: 'green' as const
  },
  {
    to: '/materials',
    title: 'Строительные материалы',
    description: 'Блоки, смеси, кирпич, доставка и остатки с объектов.',
    icon: <Package size={24} />,
    tone: 'green' as const
  },
  {
    to: '/tools',
    title: 'Инструменты',
    description: 'Инструмент купить, продать или взять в аренду.',
    icon: <Wrench size={24} />,
    tone: 'green' as const
  }
];

const steps = [
  {
    title: 'Выберите раздел',
    description: 'Откройте вакансии, резюме, технику, материалы или инструменты.',
    icon: <Search size={20} />
  },
  {
    title: 'Разместите или найдите',
    description: 'Создайте своё объявление или откликнитесь на подходящее.',
    icon: <ClipboardList size={20} />
  },
  {
    title: 'Публикация после проверки',
    description: 'После модерации объявление появляется в приложении и канале.',
    icon: <ShieldCheck size={20} />
  }
];

export function HomePage() {
  return (
    <AppPage>
      <section className="app-surface app-topline overflow-hidden rounded-panel p-5 shadow-glow app-fade-up">
        <div className="space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0 space-y-3">
              <div className="inline-flex items-center gap-2 rounded-full border border-accent-green/25 bg-accent-greenSoft px-3 py-1 text-xs font-extrabold uppercase tracking-[0.16em] text-accent-green">
                <Megaphone size={14} />
                RABST24
              </div>
              <div className="space-y-2">
                <h1 className="text-4xl font-black leading-[1.02] text-text-primary">
                  Строительная биржа в MAX
                </h1>
                <p className="text-base font-semibold leading-6 text-text-secondary">
                  Найдите работу, сотрудников, технику, материалы и инструменты в одном месте.
                </p>
              </div>
            </div>

            <div className="hidden h-16 w-16 shrink-0 items-center justify-center rounded-panel border border-accent-green/30 bg-[linear-gradient(135deg,#6ee7b7,#22c55e)] text-surface-950 shadow-[0_16px_38px_rgba(34,197,94,0.24)] min-[360px]:flex">
              <HardHat size={32} />
            </div>
          </div>

          <p className="text-sm leading-6 text-text-secondary">
            Размещайте объявления, ищите заказы, сотрудников и строительные товары. Одобренные объявления можно публиковать в связанном канале, чтобы их быстрее увидели нужные люди.
          </p>

          <div className="grid grid-cols-1 gap-2 min-[380px]:grid-cols-[1fr_1fr]">
            <Link
              to="/create"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-panel bg-[linear-gradient(135deg,#6ee7b7,#22c55e)] px-4 text-base font-black text-surface-950 shadow-glow transition duration-200 hover:brightness-105 active:scale-[0.985]"
            >
              <PlusCircle size={19} />
              Разместить
            </Link>
            <Link
              to="/vacancies"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-panel border border-white/10 bg-surface-800/92 px-4 text-base font-extrabold text-text-primary transition duration-200 hover:border-accent-green/45 hover:bg-surface-800 active:scale-[0.985]"
            >
              Открыть объявления
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3">
        {sections.map((section, index) => (
          <TileCard
            key={section.to}
            {...section}
            className={`app-fade-up ${index === sections.length - 1 ? 'col-span-2' : ''}`}
          />
        ))}
      </section>

      <section className="app-surface app-topline rounded-panel p-4 app-fade-up">
        <div className="mb-4 space-y-1">
          <h2 className="text-xl font-black text-text-primary">Как это работает</h2>
          <p className="text-sm leading-6 text-text-secondary">
            Три простых шага, чтобы быстро найти нужное или разместить объявление.
          </p>
        </div>

        <div className="grid gap-3">
          {steps.map((step, index) => (
            <div
              key={step.title}
              className="group grid grid-cols-[auto_1fr] gap-3 rounded-panel border border-white/8 bg-white/[0.035] p-3 transition duration-200 hover:border-accent-green/30 hover:bg-white/[0.055] active:scale-[0.99]"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-panel border border-accent-green/20 bg-accent-greenSoft text-accent-green">
                {step.icon}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-extrabold uppercase tracking-[0.12em] text-accent-green">
                  Шаг {index + 1}
                </p>
                <h3 className="mt-0.5 text-base font-extrabold text-text-primary">{step.title}</h3>
                <p className="mt-1 text-sm leading-5 text-text-secondary">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </AppPage>
  );
}
