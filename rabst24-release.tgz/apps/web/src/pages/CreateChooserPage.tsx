﻿import type { LucideIcon } from 'lucide-react';
import { ArrowRight, FileUser, HardHat, Package, Plus, Sparkles, Truck, Wrench } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppPage } from '../shared/ui/AppPage.js';
import { SectionCard } from '../shared/ui/SectionCard.js';

interface CreateOption {
  to: string;
  title: string;
  description: string;
  badge: string;
  icon: LucideIcon;
  accent: 'green';
}

const options: CreateOption[] = [
  {
    to: '/create/vacancy',
    title: 'Вакансия',
    description: 'Найти сотрудника на объект, в бригаду или на постоянную работу.',
    badge: 'Работодатель',
    icon: HardHat,
    accent: 'green'
  },
  {
    to: '/create/resume',
    title: 'Резюме',
    description: 'Рассказать о себе, опыте, специальности и желаемой зарплате.',
    badge: 'Соискатель',
    icon: FileUser,
    accent: 'green'
  },
  {
    to: '/create/equipment',
    title: 'Строительная техника',
    description: 'Разместить экскаватор, кран, грузовую машину или другую технику.',
    badge: 'Аренда и продажа',
    icon: Truck,
    accent: 'green'
  },
  {
    to: '/create/material',
    title: 'Строительные материалы',
    description: 'Продать материалы, блоки, смеси, кирпич или остатки после объекта.',
    badge: 'Материалы',
    icon: Package,
    accent: 'green'
  },
  {
    to: '/create/tool',
    title: 'Инструменты',
    description: 'Добавить инструмент для продажи, аренды или передачи в работу.',
    badge: 'Инструмент',
    icon: Wrench,
    accent: 'green'
  }
];

export function CreateChooserPage() {
  return (
    <AppPage>
      <section className="app-surface app-topline relative overflow-hidden rounded-panel p-5 shadow-glow app-fade-up">
        <div className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-accent-green/12 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 left-4 h-40 w-40 rounded-full bg-accent-green/10 blur-3xl" />
        <div className="relative space-y-5">
          <div className="inline-flex w-fit items-center gap-2 rounded-full border border-accent-green/25 bg-accent-greenSoft px-3 py-1 text-xs font-extrabold uppercase tracking-[0.16em] text-accent-green">
            <Sparkles size={14} />
            Размещение
          </div>
          <div className="space-y-2">
            <h1 className="max-w-sm text-3xl font-black leading-[1.06] text-text-primary">
              Что хотите разместить?
            </h1>
            <p className="max-w-md text-base leading-6 text-text-secondary">
              Выберите тип объявления. Мы откроем короткую форму только с нужными полями.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 text-xs font-bold text-text-muted">
            <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5">5 типов объявлений</span>
            <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5">Проверка перед публикацией</span>
          </div>
        </div>
      </section>

      <section className="grid gap-3" aria-label="Типы объявлений">
        {options.map((option, index) => (
          <CreateTypeCard key={option.to} option={option} index={index} />
        ))}
      </section>

      <SectionCard title="После отправки" description="Объявление уйдёт на модерацию. После проверки оно появится в ленте и будет готово для откликов.">
        <div className="grid gap-2 text-sm leading-6 text-text-secondary">
          <p>Формы короткие: фото, название, описание, цена или зарплата, контакт и адрес.</p>
          <p>Без лишних технических полей, чтобы человек мог разместиться с телефона за пару минут.</p>
        </div>
      </SectionCard>
    </AppPage>
  );
}

function CreateTypeCard({ option, index }: { option: CreateOption; index: number }) {
  const Icon = option.icon;

  return (
    <Link
      to={option.to}
      className="app-surface app-topline group relative overflow-hidden rounded-panel p-4 transition duration-200 hover:translate-y-[-2px] hover:border-accent-green/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent-green active:scale-[0.985]"
      style={{ animationDelay: `${index * 45}ms` }}
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[linear-gradient(90deg,transparent,rgba(52,211,153,0.75),transparent)] opacity-70" />
      <div className="flex items-start justify-between gap-4">
        <div className="flex min-w-0 gap-3">
          <div className={accentClass(option.accent)}>
            <Icon size={24} />
          </div>
          <div className="min-w-0 space-y-2">
            <span className="inline-flex rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-[0.12em] text-text-muted">
              {option.badge}
            </span>
            <div className="space-y-1">
              <h2 className="text-xl font-black text-text-primary">{option.title}</h2>
              <p className="max-w-md text-sm leading-6 text-text-secondary">{option.description}</p>
            </div>
          </div>
        </div>
        <div className="flex min-h-11 min-w-11 items-center justify-center rounded-full border border-white/10 bg-white/[0.03] text-text-muted transition group-hover:border-accent-green/35 group-hover:text-accent-green">
          <ArrowRight size={18} />
        </div>
      </div>
      <div className="mt-4 flex items-center justify-between gap-3 border-t border-white/6 pt-3 text-sm">
        <span className="inline-flex items-center gap-2 font-semibold text-text-muted">
          <Plus size={15} />
          Шаг {index + 1}
        </span>
        <span className="font-extrabold text-text-primary">Открыть форму</span>
      </div>
    </Link>
  );
}

function accentClass(accent: CreateOption['accent']) {
  const base = 'flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border shadow-[0_0_24px_rgba(0,0,0,0.14)]';

  if (accent === 'green') {
    return `${base} border-accent-green/25 bg-accent-greenSoft text-accent-green`;
  }

  return `${base} border-accent-green/25 bg-accent-greenSoft text-accent-green`;
}
