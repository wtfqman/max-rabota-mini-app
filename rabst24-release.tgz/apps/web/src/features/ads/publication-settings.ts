﻿export type RepeatPeriod = 'daily' | 'three_days' | 'weekly';
export type ActivePeriod = 'three_days' | 'seven_days' | 'fourteen_days' | 'manual';

export interface PublicationSettings {
  adId: string;
  autoRepeat: boolean;
  repeatPeriod: RepeatPeriod;
  activePeriod: ActivePeriod;
  remindBeforeEnd: boolean;
  updatedAt: string;
}

export type PublicationSettingsMap = Record<string, PublicationSettings>;

export const repeatPeriodOptions: Array<{ value: RepeatPeriod; label: string }> = [
  { value: 'daily', label: 'каждый день' },
  { value: 'three_days', label: 'раз в 3 дня' },
  { value: 'weekly', label: 'раз в неделю' }
];

export const activePeriodOptions: Array<{ value: ActivePeriod; label: string }> = [
  { value: 'three_days', label: '3 дня' },
  { value: 'seven_days', label: '7 дней' },
  { value: 'fourteen_days', label: '14 дней' },
  { value: 'manual', label: 'вручную отключить' }
];

const STORAGE_KEY = 'rabst24:publication-settings:v1';

export function defaultPublicationSettings(adId: string): PublicationSettings {
  return {
    adId,
    autoRepeat: false,
    repeatPeriod: 'three_days',
    activePeriod: 'seven_days',
    remindBeforeEnd: true,
    updatedAt: new Date().toISOString()
  };
}

export function loadPublicationSettings(): PublicationSettingsMap {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as PublicationSettingsMap) : {};
  } catch {
    return {};
  }
}

export function savePublicationSettings(settings: PublicationSettingsMap): void {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
}

export function getPublicationSettings(
  settings: PublicationSettingsMap,
  adId: string
): PublicationSettings {
  return settings[adId] ?? defaultPublicationSettings(adId);
}

export function upsertPublicationSettings(
  settings: PublicationSettingsMap,
  nextSettings: PublicationSettings
): PublicationSettingsMap {
  const next = {
    ...settings,
    [nextSettings.adId]: {
      ...nextSettings,
      updatedAt: new Date().toISOString()
    }
  };

  savePublicationSettings(next);
  return next;
}

export function removePublicationSettings(settings: PublicationSettingsMap, adId: string): PublicationSettingsMap {
  const next = { ...settings };
  delete next[adId];
  savePublicationSettings(next);
  return next;
}
